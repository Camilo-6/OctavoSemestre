from skimage.io import imread
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog, Menu
from PIL import Image, ImageTk
import numpy as np
import cv2
import matplotlib.pyplot as plt

# Este programa requiere tener instalados los siguientes paquetes:
# - tkinter
# - scikit-image
# - numpy
# - pillow
# - math
# - opencv-python
# - matplotlib
# Para instalar estos paquetes, puedes usar el siguiente comando:
# pip install tk scikit-image numpy pillow opencv-python matplotlib
# Nota:
# - Si usas un sistema basado en Linux, como Ubuntu o Fedora, y encuentras problemas con tkinter,
#   es posible que debas instalarlo manualmente. En Fedora, puedes instalarlo con:
#     sudo dnf install python3-tkinter
#   - Para instalar `ImageTk` correctamente en Fedora, tambien necesitas:
#     sudo dnf install python3-pillow-tk
# - Si `ImageTk` no se encuentra, asegurate de tener Pillow instalado correctamente, 
#   en caso de que no funcione.

# Si se usan imagenes muy grandes (como ave1.jpeg), puede que no se muestren correctamente en la interfaz grafica, se recomienda usar imagenes pequenias (como patito.jpg)
# Ademas, los filtros pueden ser tardados en aplicarse en imagenes grandes o medianas

# Funcion para solo dejar el valor R de cada pixel en la imagen
def red(imagen):
    img = imread(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i, j, 1] = 0
            img[i, j, 2] = 0
    return img

# Funcion para solo dejar el valor G de cada pixel en la imagen
def green(imagen):
    img = imread(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i, j, 0] = 0
            img[i, j, 2] = 0
    return img

# Funcion para solo dejar el valor B de cada pixel en la imagen
def blue(imagen):
    img = imread(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i, j, 0] = 0
            img[i, j, 1] = 0
    return img

# Funcion para pasar una imagen a escala de grises
def escala_grises(imagen):
    img = imread(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            r = int(img[i, j, 0])
            g = int(img[i, j, 1])
            b = int(img[i, j, 2])
            tono = int(0.2126*r + 0.7152*g + 0.0722*b)
            img[i, j, 0] = tono
            img[i, j, 1] = tono
            img[i, j, 2] = tono
    return img

# Funcion para pasar una imagen a escala de grises con un metodo mas simple
def escala_grises_simple(imagen):
    img = imread(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            r = int(img[i, j, 0])
            g = int(img[i, j, 1])
            b = int(img[i, j, 2])
            tono = (r + g + b) // 3
            img[i, j, 0] = tono
            img[i, j, 1] = tono
            img[i, j, 2] = tono
    return img

# Funcion para aplicar alto contraste a una imagen (primero se pasa a escala de grises y luego se revisa si el tono es mayor o menor a 128)
def alto_contraste(imagen):
    img = escala_grises(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            if img[i, j, 0] > 128:
                img[i, j, 0] = 255
                img[i, j, 1] = 255
                img[i, j, 2] = 255
            else:
                img[i, j, 0] = 0
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    return img

# Funcion para aplicar el contrario de alto contraste a una imagen
def inverso(imagen):
    img = escala_grises(imagen)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            if img[i, j, 0] <= 128:
                img[i, j, 0] = 255
                img[i, j, 1] = 255
                img[i, j, 2] = 255
            else:
                img[i, j, 0] = 0
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    return img

# Funcion para aplicar el filtro brillo (-255 <= variable <= 255)
def brillo(imagen, variable):
    img = imread(imagen).astype(np.int16)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            for k in range(3):
                valor = img[i, j, k] + variable
                if valor < 0:
                    img[i, j, k] = 0
                elif valor > 255:
                    img[i, j, k] = 255
                else:
                    img[i, j, k] = valor
    return img.astype(np.uint8)

# Funcion para aplicar el filtro componentes RGB (0 <= r, g, b <= 255)
def componentes_rgb(imagen, r, g, b):
    img = imread(imagen).astype(np.uint8)
    for i in range(img.shape[0]):
        for j in range(img.shape[1]):
            img[i, j, 0] = img[i, j, 0] & r
            img[i, j, 1] = img[i, j, 1] & g
            img[i, j, 2] = img[i, j, 2] & b
    return img

# Funcion para aplicar el filtro mosaico, divide la imagen en bloques y saca el promedio de cada bloque
def mosaico(imagen, x, y):
    img = imread(imagen).astype(np.uint8)
    for i in range(0, img.shape[0], x):
        for j in range(0, img.shape[1], y):
            r = np.uint64(0)
            g = np.uint64(0)
            b = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + x, img.shape[0])):
                for l in range(j, min(j + y, img.shape[1])):
                    r += img[k, l, 0]
                    g += img[k, l, 1]
                    b += img[k, l, 2]
                    pixeles += 1
            r //= pixeles
            g //= pixeles
            b //= pixeles
            for k in range(i, min(i + x, img.shape[0])):
                for l in range(j, min(j + y, img.shape[1])):
                    img[k, l, 0] = r
                    img[k, l, 1] = g
                    img[k, l, 2] = b
    return img


# Funcion para aplicar un filtro donde cada region de pixeles se convierte a un caracter @ en un archivo HTML y respeta el color de la region
def imagen_a_html(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                r = np.uint64(0)
                g = np.uint64(0)
                b = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        r += img[k, l, 0]
                        g += img[k, l, 1]
                        b += img[k, l, 2]
                        pixeles += 1
                r //= pixeles
                g //= pixeles
                b //= pixeles
                f.write(f"<span style='color: rgb({r},{g},{b})'>{"@"}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para aplicar un filtro donde cada region de pixeles se convierte a un caracter @ en un archivo HTML y usa escala de grises
def imagen_a_html_gris(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                gris = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris += img[k, l, 0]
                        pixeles += 1
                gris //= pixeles
                f.write(f"<span style='color: rgb({gris},{gris},{gris})'>{"@"}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para aplicar un filtro donde cada region de pixeles se convierte en un caracter especifico, dependiendo de su tono en escala de grises, en un archivo HTML
def imagen_a_html_letras(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                gris = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris += img[k, l, 0]
                        pixeles += 1
                gris //= pixeles
                simbolo = gris_a_letra(gris)
                f.write(f"<span>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para obtener la letra dependiendo del tono de gris
def gris_a_letra(tono):
    if tono < 16:
        return "M"
    elif tono < 32:
        return "N"
    elif tono < 48:
        return "H"
    elif tono < 64:
        return "#"
    elif tono < 80:
        return "Q"
    elif tono < 96:
        return "U"
    elif tono < 112:
        return "A"
    elif tono < 128:
        return "D"
    elif tono < 144:
        return "0"
    elif tono < 160:
        return "Y"
    elif tono < 176:
        return "2"
    elif tono < 192:
        return "$"
    elif tono < 208:
        return "%"
    elif tono < 224:
        return "+"
    elif tono < 240:
        return "."
    else:
        return " "

# Funcion para aplicar un filtro donde cada region de pixeles se convierte en un un caracter de una cadena en un archivo HTML y respeta el color de la region
def imagen_a_html_cadena(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y, cadena):
    img = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        posicion = 0
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                r = np.uint64(0)
                g = np.uint64(0)
                b = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        r += img[k, l, 0]
                        g += img[k, l, 1]
                        b += img[k, l, 2]
                        pixeles += 1
                r //= pixeles
                g //= pixeles
                b //= pixeles
                simbolo = cadena[posicion % len(cadena)]
                posicion += 1
                f.write(f"<span style='color: rgb({r},{g},{b})'>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para aplicar un filtro donde cada dos regiones de pixeles se convierten en una pieza de domino horizontal en un archivo HTML
def imagen_a_domino(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x * 2):
                gris_parte1 = np.uint64(0)
                pixeles_parte1 = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris_parte1 += img[k, l, 0]
                        pixeles_parte1 += 1
                if pixeles_parte1 == 0:
                    continue
                else:
                    gris_parte1 //= pixeles_parte1
                gris_parte2 = np.uint64(0)
                pixeles_parte2 = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j + tam_x, min(j + tam_x * 2, ancho)):
                        gris_parte2 += img[k, l, 0]
                        pixeles_parte2 += 1
                if pixeles_parte2 == 0:
                    gris_parte2 = gris_parte1
                else:
                    gris_parte2 //= pixeles_parte2
                simbolo = piezas_domino[(gris_a_numero_domino(gris_parte1), gris_a_numero_domino(gris_parte2))]
                f.write(f"<span>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para obtener el numero de domino dependiendo del tono de gris
def gris_a_numero_domino(tono):
    if tono < 37:
        return 6
    elif tono < 74:
        return 5
    elif tono < 111:
        return 4
    elif tono < 148:
        return 3
    elif tono < 185:
        return 2
    elif tono < 222:
        return 1
    else:
        return 0

# Diccionario para obtener el codigo HTML de una pieza de domino vertical dependiendo de sus numeros
piezas_domino = {
    (0, 0): "&#127025;",
    (0, 1): "&#127026;",
    (0, 2): "&#127027;",
    (0, 3): "&#127028;",
    (0, 4): "&#127029;",
    (0, 5): "&#127030;",
    (0, 6): "&#127031;",
    (1, 0): "&#127032;",
    (1, 1): "&#127033;",
    (1, 2): "&#127034;",
    (1, 3): "&#127035;",
    (1, 4): "&#127036;",
    (1, 5): "&#127037;",
    (1, 6): "&#127038;",
    (2, 0): "&#127039;",
    (2, 1): "&#127040;",
    (2, 2): "&#127041;",
    (2, 3): "&#127042;",
    (2, 4): "&#127043;",
    (2, 5): "&#127044;",
    (2, 6): "&#127045;",
    (3, 0): "&#127046;",
    (3, 1): "&#127047;",
    (3, 2): "&#127048;",
    (3, 3): "&#127049;",
    (3, 4): "&#127050;",
    (3, 5): "&#127051;",
    (3, 6): "&#127052;",
    (4, 0): "&#127053;",
    (4, 1): "&#127054;",
    (4, 2): "&#127055;",
    (4, 3): "&#127056;",
    (4, 4): "&#127057;",
    (4, 5): "&#127058;",
    (4, 6): "&#127059;",
    (5, 0): "&#127060;",
    (5, 1): "&#127061;",
    (5, 2): "&#127062;",
    (5, 3): "&#127063;",
    (5, 4): "&#127064;",
    (5, 5): "&#127065;",
    (5, 6): "&#127066;",
    (6, 0): "&#127067;",
    (6, 1): "&#127068;",
    (6, 2): "&#127069;",
    (6, 3): "&#127070;",
    (6, 4): "&#127071;",
    (6, 5): "&#127072;",
    (6, 6): "&#127073;"
}

# Funcion para aplicar un filtro donde cada dos regiones de pixeles se convierten en una pieza de domino horizontal en un archivo HTML, usando una fuente
def imagen_a_domino_fuente(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"""<html><head><style>@font-face {{font-family: 'Lasvwd';src: url('/imagenes/fuentes/Lasvbld_.ttf') format('truetype');}}body {{background-color: white;}}
                pre {{font-family: 'Lasvwd', monospace;font-size: {tam_letra}px;line-height: {esp_entre_linea}px;}}</style></head><body><pre>""")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x * 2):
                gris_parte1 = np.uint64(0)
                pixeles_parte1 = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris_parte1 += img[k, l, 0]
                        pixeles_parte1 += 1
                if pixeles_parte1 == 0:
                    continue
                else:
                    gris_parte1 //= pixeles_parte1
                gris_parte2 = np.uint64(0)
                pixeles_parte2 = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j + tam_x, min(j + tam_x * 2, ancho)):
                        gris_parte2 += img[k, l, 0]
                        pixeles_parte2 += 1
                if pixeles_parte2 == 0:
                    gris_parte2 = gris_parte1
                else:
                    gris_parte2 //= pixeles_parte2
                simbolo = piezas_domino_fuente[(gris_a_numero_domino_fuente(gris_parte1), gris_a_numero_domino_fuente(gris_parte2))]
                f.write(f"<span style='font-family: Lasvwd;'>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para obtener el numero de domino dependiendo del tono de gris
def gris_a_numero_domino_fuente(tono):
    if tono < 25:
        return 0
    elif tono < 51:
        return 1
    elif tono < 77:
        return 2
    elif tono < 103:
        return 3
    elif tono < 129:
        return 4
    elif tono < 155:
        return 5
    elif tono < 181:
        return 6
    elif tono < 207:
        return 7
    elif tono < 233:
        return 8
    else:
        return 9

# Diccionario para obtener el codigo HTML de una pieza de domino vertical dependiendo de sus numeros
piezas_domino_fuente = {
    (0, 0): "00",
    (0, 1): "01",
    (0, 2): "02",
    (0, 3): "03",
    (0, 4): "04",
    (0, 5): "05",
    (0, 6): "06",
    (0, 7): "07",
    (0, 8): "08",
    (0, 9): "09",
    (1, 0): "10",
    (1, 1): "11",
    (1, 2): "12",
    (1, 3): "13",
    (1, 4): "14",
    (1, 5): "15",
    (1, 6): "16",
    (1, 7): "17",
    (1, 8): "18",
    (1, 9): "19",
    (2, 0): "20",
    (2, 1): "21",
    (2, 2): "22",
    (2, 3): "23",
    (2, 4): "24",
    (2, 5): "25",
    (2, 6): "26",
    (2, 7): "27",
    (2, 8): "28",
    (2, 9): "29",
    (3, 0): "30",
    (3, 1): "31",
    (3, 2): "32",
    (3, 3): "33",
    (3, 4): "34",
    (3, 5): "35",
    (3, 6): "36",
    (3, 7): "37",
    (3, 8): "38",
    (3, 9): "39",
    (4, 0): "40",
    (4, 1): "41",
    (4, 2): "42",
    (4, 3): "43",
    (4, 4): "44",
    (4, 5): "45",
    (4, 6): "46",
    (4, 7): "47",
    (4, 8): "48",
    (4, 9): "49",
    (5, 0): "50",
    (5, 1): "51",
    (5, 2): "52",
    (5, 3): "53",
    (5, 4): "54",
    (5, 5): "55",
    (5, 6): "56",
    (5, 7): "57",
    (5, 8): "58",
    (5, 9): "59",
    (6, 0): "60",
    (6, 1): "61",
    (6, 2): "62",
    (6, 3): "63",
    (6, 4): "64",
    (6, 5): "65",
    (6, 6): "66",
    (6, 7): "67",
    (6, 8): "68",
    (6, 9): "69",
    (7, 0): "70",
    (7, 1): "71",
    (7, 2): "72",
    (7, 3): "73",
    (7, 4): "74",
    (7, 5): "75",
    (7, 6): "76",
    (7, 7): "77",
    (7, 8): "78",
    (7, 9): "79",
    (8, 0): "80",
    (8, 1): "81",
    (8, 2): "82",
    (8, 3): "83",
    (8, 4): "84",
    (8, 5): "85",
    (8, 6): "86",
    (8, 7): "87",
    (8, 8): "88",
    (8, 9): "89",
    (9, 0): "90",
    (9, 1): "91",
    (9, 2): "92",
    (9, 3): "93",
    (9, 4): "94",
    (9, 5): "95",
    (9, 6): "96",
    (9, 7): "97",
    (9, 8): "98",
    (9, 9): "99"
}

# Funcion para aplicar un filtro donde cada region de pixeles se convierten en una carta en un archivo HTML
def imagen_a_carta(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"<html><body style='background-color: white;'><pre style='font-family: monospace; font-size: {tam_letra}px; line-height: {esp_entre_linea}px;'>\n")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                gris = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris += img[k, l, 0]
                        pixeles += 1
                gris //= pixeles
                simbolo = cartas[gris_a_numero_carta(gris)]
                f.write(f"<span>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para obtener el numero de carta dependiendo del tono de gris
def gris_a_numero_carta(tono):
    if tono < 23:
        return 11
    elif tono < 46:
        return 10
    elif tono < 69:
        return 9
    elif tono < 92:
        return 8
    elif tono < 115:
        return 7
    elif tono < 138:
        return 6
    elif tono < 161:
        return 5
    elif tono < 184:
        return 4
    elif tono < 207:
        return 3
    elif tono < 230:
        return 2
    else:
        return 1

# Diccionario para obtener el codigo HTML de una carta dependiendo de su numero
cartas = {
    (1): "&#127169;",
    (2): "&#127170;",
    (3): "&#127171;",
    (4): "&#127172;",
    (5): "&#127173;",
    (6): "&#127174;",
    (7): "&#127175;",
    (8): "&#127176;",
    (9): "&#127177;",
    (10): "&#127178;",
    (11): "&#127180;"
}

# Funcion para aplicar un filtro donde cada region de pixeles se convierten en una carta en un archivo HTML, usando una fuente
def imagen_a_carta_fuente(imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    with open(salida, "w") as f:
        f.write(f"""<html><head><style>@font-face {{font-family: 'PlayCards';src: url('/imagenes/fuentes/Playcrds.ttf') format('truetype');}}body {{background-color: white;}}
                pre {{font-family: 'PlayCards', monospace;font-size: {tam_letra}px;line-height: {esp_entre_linea}px;}}</style></head><body><pre>""")
        for i in range(0, alto, tam_y):
            for j in range(0, ancho, tam_x):
                gris = np.uint64(0)
                pixeles = 0
                for k in range(i, min(i + tam_y, alto)):
                    for l in range(j, min(j + tam_x, ancho)):
                        gris += img[k, l, 0]
                        pixeles += 1
                gris //= pixeles
                simbolo = cartas[gris_a_numero_carta(gris)]
                f.write(f"<span style='font-family: PlayCards;'>{simbolo}</span>")
            f.write("<br>\n")
        f.write("</pre></body></html>")

# Funcion para obtener el numero de carta dependiendo del tono de gris
def gris_a_numero_carta_fuente(tono):
    if tono < 25:
        return 0
    elif tono < 51:
        return 1
    elif tono < 77:
        return 2
    elif tono < 103:
        return 3
    elif tono < 129:
        return 4
    elif tono < 155:
        return 5
    elif tono < 181:
        return 6
    elif tono < 207:
        return 7
    elif tono < 233:
        return 8
    else:
        return 9

# Diccionario para obtener el codigo HTML de una carta dependiendo de su numero
cartas_fuente = {
    (0): "m",
    (1): "i",
    (2): "h",
    (3): "g",
    (4): "f",
    (5): "e",
    (6): "d",
    (7): "c",
    (8): "b",
    (9): "a"
}


""" # Filtro para quitar la marca de agua roja de una imagen en escala de grises
def quitar_marca_agua(imagen):
    img = imread(imagen).astype(np.uint32)
    img_gris = escala_grises(imagen)
    alto, ancho, canales = img.shape
    mascara = np.zeros((alto, ancho), dtype=np.uint8)
    tole = 5
    for i in range(alto):
        for j in range(ancho):
            if img[i, j, 0] > img[i, j, 1] + tole and img[i, j, 0] > img[i, j, 2] + tole:
                mascara[i, j] = 255
    for i in range(alto):
        for j in range(ancho):
            if mascara[i, j] == 255:
                r_o = img[i, j, 0]
                g_o = img[i, j, 1]
                b_o = img[i, j, 2]
                gris = (r_o + g_o + b_o) // 3
                gris += estimar_brillo(img_gris, i, j, mascara)
                if gris < 0:
                    gris = 0
                elif gris > 255:
                    gris = 255
                img[i, j, 0] = gris
                img[i, j, 1] = gris
                img[i, j, 2] = gris
    return img.astype(np.uint8)

# Funcion para estimar el brillo de un pixel usando sus vecinos que no esten en la mascara
def estimar_brillo(img, i, j, mascara):
    vecinos = []
    radio = 1
    radio_max = 10
    alto, ancho, canales = img.shape
    cantidad_vec = 3
    for radio in range(1, radio_max + 1):
        if len(vecinos) >= cantidad_vec:
            break
        for k in range(i - radio, i + radio + 1):
            for l in range(j - radio, j + radio + 1):
                if 0 <= k < alto and 0 <= l < ancho and (k != i or l != j) and mascara[k, l] == 0:
                    vecinos.append(img[k, l, 0])
    if len(vecinos) == 0:
        return 0
    promedio = np.int32(0)
    for v in vecinos:
        promedio += v
    promedio //= len(vecinos)
    if promedio < 42:
        return -75
    elif promedio < 84:
        return -50
    elif promedio < 126:
        return -25
    elif promedio < 168:
        return 0
    elif promedio < 210:
        return 25
    elif promedio < 252:
        return 50
    else:
        return 75 """


# Funcion para aplicar un filtro donde cada region de pixeles se convierte en una imagen con el filtro componentes RGB aplicado
def recursion_colores_reales(imagen, tam_x, tam_y, imagen_micas, final_x, final_y):
    micas, orden, cant_regiones_y, cant_regiones_x = crear_micas_color(imagen, tam_x, tam_y, imagen_micas)
    img = crear_recursion(final_x, final_y, micas, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para crear un diccionario con imagenes aplicada con el filtro componentes RGB basado en la imagen original y sus regiones de pixeles
def crear_micas_color(imagen, tam_x, tam_y, imagen_micas):
    img_1 = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    micas = {}
    orden = []
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            r = np.uint64(0)
            g = np.uint64(0)
            b = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    r += img_1[k, l, 0]
                    g += img_1[k, l, 1]
                    b += img_1[k, l, 2]
                    pixeles += 1
            r //= pixeles
            g //= pixeles
            b //= pixeles
            r = np.uint8(r)
            g = np.uint8(g)
            b = np.uint8(b)
            if micas.get((r, g, b)) is None:
                micas[(r, g, b)] = componentes_rgb(imagen_micas, r, g, b)
                print(f"Se ha creado una mica para el color ({r}, {g}, {b})")
            orden.append((r, g, b))
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return micas, orden, cant_regones_y, cant_regiones_x

# Funcion para crear una nueva imagen usando las micas creadas, cambiando su tamanio, dependiendo de las regiones de pixeles de la imagen original
def crear_recursion(final_x, final_y, micas, orden, cant_regiones_y, cant_regiones_x):
    img_2 = np.ones((cant_regiones_y * final_y, cant_regiones_x * final_x, 3), np.uint8) * 255
    alto, ancho, canales = img_2.shape
    for i in range(0, alto, final_y):
        for j in range(0, ancho, final_x):
            r_g_b = orden.pop(0)
            r = r_g_b[0]
            g = r_g_b[1]
            b = r_g_b[2]
            mica = micas[(r, g, b)]
            #mica_tam = cv2.resize(mica, (final_x, final_y), interpolation=cv2.INTER_LINEAR) # usar con opencv-python
            mica_tam = reducir(mica, final_x, final_y)
            for k in range(final_y):
                for l in range(final_x):
                    img_2[i + k, j + l, 0] = mica_tam[k, l, 0]
                    img_2[i + k, j + l, 1] = mica_tam[k, l, 1]
                    img_2[i + k, j + l, 2] = mica_tam[k, l, 2]
            print(f"Quedan {len(orden)} regiones por procesar")
    return img_2

# Funcion para reducir el tamanio de una imagen, creando una nueva
def reducir(imagen, tam_x, tam_y):
    alto, ancho, canales = imagen.shape
    if tam_x > ancho or tam_y > alto:
        raise ValueError("Error al reducir la imagen, el tamanio es mayor que la imagen original")
    img_1 = np.ones((tam_x, tam_y, 3), np.uint8) * 255
    bloque_y = alto // tam_y
    bloque_x = ancho // tam_x
    for i in range(tam_y):
        for j in range(tam_x):
            r = np.uint64(0)
            g = np.uint64(0)
            b = np.uint64(0)
            pixeles = 0
            for k in range(i * bloque_y, min((i + 1) * bloque_y, alto)):
                for l in range(j * bloque_x, min((j + 1) * bloque_x, ancho)):
                    r += imagen[k, l, 0]
                    g += imagen[k, l, 1]
                    b += imagen[k, l, 2]
                    pixeles += 1 
            r //= pixeles
            g //= pixeles
            b //= pixeles
            img_1[i, j, 0] = r
            img_1[i, j, 1] = g
            img_1[i, j, 2] = b
    return img_1


# Funcion para aplicar dithering al azar a una imagen en escala de grises
def dithering_azar(imagen):
    img = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    for i in range(alto):
        for j in range(ancho):
            valor = np.random.randint(0, 256)
            if img[i, j, 0] >= valor:
                img[i, j, 0] = 255
                img[i, j, 1] = 255
                img[i, j, 2] = 255
            else:
                img[i, j, 0] = 0
                img[i, j, 1] = 0
                img[i, j, 2] = 0
    return img

# Funcion para aplicar dithering usando una matriz cuadrada y una imagen en escala de grises
def dithering_matriz(imagen, matriz, div):
    img = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    tam = len(matriz)
    for i in range(0, alto, tam):
        for j in range(0, ancho, tam):
            for k in range(tam):
                for l in range(tam):
                    if i + k >= alto or j + l >= ancho:
                        continue
                    valor = img[i + k, j + l, 0]
                    valor //= div
                    valor_matriz = matriz[k][l]
                    if valor < valor_matriz:
                        img[i + k, j + l, 0] = 0
                        img[i + k, j + l, 1] = 0
                        img[i + k, j + l, 2] = 0
                    else:
                        img[i + k, j + l, 0] = 255
                        img[i + k, j + l, 1] = 255
                        img[i + k, j + l, 2] = 255
    return img

# Funcion para aplicar dithering ordenado
def dithering_ordenado(imagen):
    matriz = [[8, 3, 4], [6, 1, 2], [7, 5, 9]]
    return dithering_matriz(imagen, matriz, 28)

# Funcion para aplicar dithering disperso 3x3
def dithering_disperso(imagen):
    matriz = [[1, 7, 4], [5, 8, 3], [6, 2, 9]]
    return dithering_matriz(imagen, matriz, 28)

# Funcion para aplicar dithering disperso 2x2
def dithering_disperso_2x2(imagen):
    matriz = [[1, 3], [4, 2]]
    return dithering_matriz(imagen, matriz, 64)

# Funcion para aplicar dithering disperso 4x4
def dithering_disperso_4x4(imagen):
    matriz = [[1, 9, 3, 11], [13, 5, 15, 7], [4, 12, 2, 10], [16, 8, 14, 6]]
    return dithering_matriz(imagen, matriz, 15)

# Funcion para aplicar dithering usando una matriz para pasar el error a los vecinos y una imagen en escala de grises
def dithering_error(imagen, matriz, div, pos_x, pos_y):
    img = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    tam_x = len(matriz[0])
    tam_y = len(matriz)
    extra = np.zeros((alto, ancho), dtype=np.float64)
    for i in range(alto):
        for j in range(ancho):
            valor = img[i, j, 0].astype(np.float64)
            valor += extra[i, j]
            error = np.float64(0)
            nuevo_valor = 0 if valor < 127.5 else 255
            error = valor - nuevo_valor
            img[i, j, 0] = nuevo_valor
            img[i, j, 1] = nuevo_valor
            img[i, j, 2] = nuevo_valor
            for k in range(tam_y):
                for l in range(tam_x):
                    if matriz[k][l] == 0 or matriz[k][l] == -1:
                        continue
                    pos_x_imagen = i + k - pos_y
                    pos_y_imagen = j + l - pos_x
                    if 0 <= pos_x_imagen < alto and 0 <= pos_y_imagen < ancho:
                        extra[pos_x_imagen, pos_y_imagen] += (error * matriz[k][l] / div)
    return img.astype(np.uint8)

# Funcion para aplicar dithering de Floyd-Steinberg
def dithering_floyd_steinberg(imagen):
    matriz = [[0, -1, 7], [3, 5, 1]]
    return dithering_error(imagen, matriz, 16, 1, 0)

# Funcion para aplicar dithering de Floyd-Steinberg falso (2x2)
def dithering_floyd_steinberg_falso(imagen):
    matriz = [[-1, 3], [3, 2]]
    return dithering_error(imagen, matriz, 8, 0, 0)

# Funcion para aplicar dithering de Jarvis, Judice y Ninke
def dithering_jarvis_judice_ninke(imagen):
    matriz = [[0, 0, -1, 7, 5], [3, 5, 7, 5, 3], [1, 3, 5, 3, 1]]
    return dithering_error(imagen, matriz, 48, 2, 0)


# Funcion para aplicar semitonos con circulos
def semitonos_circulos(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_circulo(imagen, tam_x, tam_y)
    img = crear_semitono(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar semitonos con circulos
def crear_orden_circulo(imagen, tam_x, tam_y):
    img_1 = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    gris += img_1[k, l, 0]
                    pixeles += 1
            gris //= pixeles
            gris = np.uint8(gris)
            if gris < 27:
                orden.append(0)
            elif gris < 54:
                orden.append(1)
            elif gris < 81:
                orden.append(2)
            elif gris < 108:
                orden.append(3)
            elif gris < 135:
                orden.append(4)
            elif gris < 162:
                orden.append(5)
            elif gris < 189:
                orden.append(6)
            elif gris < 216:
                orden.append(7)
            elif gris < 243:
                orden.append(8)
            else:
                orden.append(9)
    for i in range(10):
        imagenes[(i)] = imread(f"imagenes/semitonos/a{i+1}.jpg").astype(np.uint8)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para aplicar semitonos con matriz 3x3
def semitonos_3x3(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_3x3(imagen, tam_x, tam_y)
    img = crear_semitono_especial(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar semitonos con matriz 3x3
def crear_orden_3x3(imagen, tam_x, tam_y):
    img_1 = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    gris += img_1[k, l, 0]
                    pixeles += 1
            gris //= pixeles
            gris = np.uint8(gris)
            if gris < 27:
                orden.append(9)
            elif gris < 54:
                orden.append(8)
            elif gris < 81:
                orden.append(7)
            elif gris < 108:
                orden.append(6)
            elif gris < 135:
                orden.append(5)
            elif gris < 162:
                orden.append(4)
            elif gris < 189:
                orden.append(3)
            elif gris < 216:
                orden.append(2)
            elif gris < 243:
                orden.append(1)
            else:
                orden.append(0)
    for i in range(10):
        imagenes[(i)] = imread(f"imagenes/semitonos/b{i}.jpg").astype(np.uint8)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para aplicar semitonos con matriz 2x2
def semitonos_2x2(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_2x2(imagen, tam_x, tam_y)
    img = crear_semitono_especial(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar semitonos con matriz 2x2
def crear_orden_2x2(imagen, tam_x, tam_y):
    img_1 = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    gris += img_1[k, l, 0]
                    pixeles += 1
            gris //= pixeles
            gris = np.uint8(gris)
            if gris < 51:
                orden.append(4)
            elif gris < 102:
                orden.append(3)
            elif gris < 153:
                orden.append(2)
            elif gris < 204:
                orden.append(1)
            else:
                orden.append(0)
    for i in range(5):
        imagenes[(i)] = imread(f"imagenes/semitonos/c{i}.jpg").astype(np.uint8)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para aplicar semitonos con dados con puntos grandes
def semitonos_dado_grande(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_dado_grande(imagen, tam_x, tam_y)
    img = crear_semitono(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar semitonos con dados con puntos grandes
def crear_orden_dado_grande(imagen, tam_x, tam_y):
    img_1 = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    gris += img_1[k, l, 0]
                    pixeles += 1
            gris //= pixeles
            gris = np.uint8(gris)
            if gris < 37:
                orden.append(0)
            elif gris < 74:
                orden.append(1)
            elif gris < 111:
                orden.append(2)
            elif gris < 148:
                orden.append(3)
            elif gris < 185:
                orden.append(4)
            elif gris < 222:
                orden.append(5)
            else:
                orden.append(6)
    for i in range(7):
        imagenes[(i)] = imread(f"imagenes/semitonos/g{i}d.jpg").astype(np.uint8)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para aplicar semitonos con dados
def semitonos_dado(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_dado(imagen, tam_x, tam_y)
    img = crear_semitono(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar semitonos con dados
def crear_orden_dado(imagen, tam_x, tam_y):
    img_1 = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    gris += img_1[k, l, 0]
                    pixeles += 1
            gris //= pixeles
            gris = np.uint8(gris)
            if gris < 37:
                orden.append(0)
            elif gris < 74:
                orden.append(1)
            elif gris < 111:
                orden.append(2)
            elif gris < 148:
                orden.append(3)
            elif gris < 185:
                orden.append(4)
            elif gris < 222:
                orden.append(5)
            else:
                orden.append(6)
    for i in range(7):
        imagenes[(i)] = imread(f"imagenes/semitonos/m{i}d.jpg").astype(np.uint8)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para aplicar semitonos a una imagen
def crear_semitono(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x):
    img_2 = np.ones((cant_regiones_y * final_y, cant_regiones_x * final_x, 3), np.uint8) * 255
    alto, ancho, canales = img_2.shape
    for i in range(0, alto, final_y):
        for j in range(0, ancho, final_x):
            numero = orden.pop(0)
            mica = imagenes[(numero)]
            #mica_tam = cv2.resize(mica, (final_x, final_y), interpolation=cv2.INTER_LINEAR) # usar con opencv-python
            mica_tam = reducir(mica, final_x, final_y)
            for k in range(final_y):
                for l in range(final_x):
                    img_2[i + k, j + l, 0] = mica_tam[k, l, 0]
                    img_2[i + k, j + l, 1] = mica_tam[k, l, 1]
                    img_2[i + k, j + l, 2] = mica_tam[k, l, 2]
            print(f"Quedan {len(orden)} regiones por procesar")
    return img_2

# Funcion para aplicar semitonos a una iamgen
def crear_semitono_especial(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x):
    img_2 = np.ones((cant_regiones_y * final_y, cant_regiones_x * final_x, 3), np.uint8) * 255
    alto, ancho, canales = img_2.shape
    for i in range(0, alto, final_y):
        for j in range(0, ancho, final_x):
            numero = orden.pop(0)
            mica = imagenes[(numero)]
            #mica_tam = cv2.resize(mica, (final_x, final_y), interpolation=cv2.INTER_LINEAR) # usar con opencv-python
            mica_tam = reducir_especial(mica, final_x, final_y)
            for k in range(final_y):
                for l in range(final_x):
                    img_2[i + k, j + l, 0] = mica_tam[k, l, 0]
                    img_2[i + k, j + l, 1] = mica_tam[k, l, 1]
                    img_2[i + k, j + l, 2] = mica_tam[k, l, 2]
            print(f"Quedan {len(orden)} regiones por procesar")
    return img_2

# Funcion para reducir el tamanio de una imagen, creando una nueva
def reducir_especial(imagen, tam_x, tam_y):
    alto, ancho = imagen.shape
    if tam_x > ancho or tam_y > alto:
        raise ValueError("Error al reducir la imagen, el tamanio es mayor que la imagen original")
    img_1 = np.ones((tam_x, tam_y, 3), np.uint8) * 255
    bloque_y = alto // tam_y
    bloque_x = ancho // tam_x
    for i in range(tam_y):
        for j in range(tam_x):
            gris = np.uint64(0)
            pixeles = 0
            for k in range(i * bloque_y, min((i + 1) * bloque_y, alto)):
                for l in range(j * bloque_x, min((j + 1) * bloque_x, ancho)):
                    gris += imagen[k, l]
                    pixeles += 1 
            gris //= pixeles
            img_1[i, j, 0] = gris
            img_1[i, j, 1] = gris
            img_1[i, j, 2] = gris
    return img_1


# Funcion para aplicar el filtro de posterizar
def posterizar(imagen, niveles):
    factor = 256 // niveles
    img = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    for i in range(alto):
        for j in range(ancho):
            r = img[i, j, 0]
            g = img[i, j, 1]
            b = img[i, j, 2]
            r = round(((r // factor) + 0.5) * factor)
            g = round(((g // factor) + 0.5) * factor)
            b = round(((b // factor) + 0.5) * factor)
            img[i, j, 0] = r
            img[i, j, 1] = g
            img[i, j, 2] = b
    return img

# Funcion para aplicar el filtro de solarizar
def solarizar(imagen, umbral):
    img = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    for i in range(alto):
        for j in range(ancho):
            r = img[i, j, 0]
            g = img[i, j, 1]
            b = img[i, j, 2]
            if r > umbral:
                r = 255 - r
            if g > umbral:
                g = 255 - g
            if b > umbral:
                b = 255 - b
            img[i, j, 0] = r
            img[i, j, 1] = g
            img[i, j, 2] = b
    return img


# Funcion para aplicar el filtro oleo
def oleo(imagen):
    img = imread(imagen).astype(np.uint8)
    return oleo_sin(img)

# Funcion para aplicar el filtro oleo sin usar imread
def oleo_sin(imagen):
    img = imagen
    alto, ancho, canales = img.shape
    img_2 = np.ones((alto, ancho, canales), np.uint8) * 255
    tam_matriz = 6
    total = alto * ancho
    for i in range(alto):
        for j in range(ancho):
            apariciones = {}
            for k in range(i - tam_matriz, i + tam_matriz + 1):
                for l in range(j - tam_matriz, j + tam_matriz + 1):
                    if k < 0 or l < 0 or k >= alto or l >= ancho:
                        continue
                    r = img[k, l, 0]
                    g = img[k, l, 1]
                    b = img[k, l, 2]
                    if apariciones.get((r, g, b)) is None:
                        apariciones[(r, g, b)] = 1
                    else:
                        apariciones[(r, g, b)] += 1
            maximo = 0
            color = None
            for key, value in apariciones.items():
                if value > maximo:
                    maximo = value
                    color = key
            img_2[i, j, 0] = color[0]
            img_2[i, j, 1] = color[1]
            img_2[i, j, 2] = color[2]
            total -= 1
            print(f"Quedan {total} pixeles por procesar")
    return img_2

# Funcion para aplicar el filtro oleo blur
def oleo_blur(imagen, veces):
    img = imread(imagen).astype(np.uint8)
    for i in range(veces):
        print(f"Iteracion {i + 1} del blur")
        img = blur(img)
    return oleo_sin(img)

# Funcion para aplicar un filtro de convolucion
def convolucion(imagen, matriz, factor, bias, tam):
    img = imagen
    alto, ancho, canales = img.shape
    img_nueva = np.copy(img)
    for i in range(alto):
        for j in range(ancho):
            for k in range(3):
                suma = 0.0
                for x in range(tam):
                    for y in range(tam):
                        nx = min(max(i - tam // 2 + x, 0), alto - 1)
                        ny = min(max(j - tam // 2 + y, 0), ancho - 1)
                        suma += img[nx, ny, k] * matriz[x][y]
                img_nueva[i, j, k] = np.clip(int(suma * factor + bias), 0, 255)
    return img_nueva

# Funcion para aplicar el filtro blur
def blur(imagen):
    """
    matriz = [[0.0, 0.2, 0.0], [0.2, 0.2, 0.2], [0.0, 0.2, 0.0]]
    factor = 1.0
    bias = 0.0
    num = 3
    """
    matriz = [[0.0, 0.0, 1.0, 0.0, 0.0], 
              [0.0, 1.0, 1.0, 1.0, 0.0], 
              [1.0, 1.0, 1.0, 1.0, 1.0], 
              [0.0, 1.0, 1.0, 1.0, 0.0], 
              [0.0, 0.0, 1.0, 0.0, 0.0]]
    factor = 1.0 / 13.0
    bias = 0.0
    num = 5
    return convolucion(imagen, matriz, factor, bias, num)


# Funcion para aplicar el filtro AT&T
def at_t(imagen, pixeles):
    img = alto_contraste(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    img_2 = np.ones((alto, ancho, canales), np.uint8) * 255
    for i in range(0, alto, pixeles + 1):
        for j in range(ancho):
            cantidad_pixeles = 0
            for k in range(pixeles + 1):
                if i + k < alto:
                    if not(k % (pixeles + 1) == 0):
                        if (img[i + k, j, 0] == 0):
                            cantidad_pixeles += 1
            blancos = pixeles - cantidad_pixeles
            blancos_arriba = blancos // 2
            for k in range(pixeles + 1):
                if i + k < alto:
                    if not(k % (pixeles + 1) == 0):
                        if blancos_arriba > 0:
                            blancos_arriba -= 1
                        elif cantidad_pixeles > 0:
                            img_2[i + k, j, 0] = 0
                            img_2[i + k, j, 1] = 0
                            img_2[i + k, j, 2] = 0
                            cantidad_pixeles -= 1
    return img_2

# Funcion para aplicar el filtro AT&T usando la imagen en escala de grises
def at_t_2(imagen, pixeles):
    img = escala_grises(imagen)
    img = img.astype(np.uint8)
    alto, ancho, canales = img.shape
    img_2 = np.ones((alto, ancho, canales), np.uint8) * 255
    for i in range(0, alto, pixeles + 1):
        for j in range(ancho):
            cantidad_pixeles = 0
            for k in range(pixeles + 1):
                if i + k < alto:
                    if not(k % (pixeles + 1) == 0):
                        if (img[i + k, j, 0] < 128):
                            cantidad_pixeles += 1
            blancos = pixeles - cantidad_pixeles
            blancos_arriba = blancos // 2
            for k in range(pixeles + 1):
                if i + k < alto:
                    if not(k % (pixeles + 1) == 0):
                        if blancos_arriba > 0:
                            blancos_arriba -= 1
                        elif cantidad_pixeles > 0:
                            img_2[i + k, j, 0] = img[i + k, j, 0]
                            img_2[i + k, j, 1] = img[i + k, j, 1]
                            img_2[i + k, j, 2] = img[i + k, j, 2]
                            cantidad_pixeles -= 1
    return img_2


# Funcion para aplicar filtro mosaico con circulos
def mosaico_circulos(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_mosaico_circulo(imagen, tam_x, tam_y, final_x, final_y)
    img = crear_mosaico(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar mosaico con circulos
def crear_orden_mosaico_circulo(imagen, tam_x, tam_y, final_x, final_y):
    img_1 = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            r = np.uint64(0)
            g = np.uint64(0)
            b = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    r += img_1[k, l, 0]
                    g += img_1[k, l, 1]
                    b += img_1[k, l, 2]
                    pixeles += 1
            r //= pixeles
            g //= pixeles
            b //= pixeles
            r = np.uint8(r)
            g = np.uint8(g)
            b = np.uint8(b)
            orden.append((r, g, b))
            imagenes[(r, g, b)] = pintar_circulo(r, g, b, final_x, final_y)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para pintar un circulo
def pintar_circulo(r, g, b, tam_x, tam_y):
    img = np.ones((tam_y, tam_x, 3), np.uint8) * 255
    centro_x, centro_y = tam_x // 2, tam_y // 2
    radio = min(tam_x, tam_y) // 2
    cv2.circle(img, (centro_x, centro_y), radio, (int(r), int(g), int(b)), -1)
    return img

# Funcion para aplicar filtro de mosaico con estrellas
def mosaico_estrellas(imagen, tam_x, tam_y, final_x, final_y):
    orden, cant_regiones_y, cant_regiones_x, imagenes = crear_orden_mosaico_estrella(imagen, tam_x, tam_y, final_x, final_y)
    img = crear_mosaico(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x)
    return img

# Funcion para el orden para aplicar mosaico con estrellas
def crear_orden_mosaico_estrella(imagen, tam_x, tam_y, final_x, final_y):
    img_1 = imread(imagen).astype(np.uint8)
    alto, ancho, canales = img_1.shape
    orden = []
    imagenes = {}
    for i in range(0, alto, tam_y):
        for j in range(0, ancho, tam_x):
            r = np.uint64(0)
            g = np.uint64(0)
            b = np.uint64(0)
            pixeles = 0
            for k in range(i, min(i + tam_y, alto)):
                for l in range(j, min(j + tam_x, ancho)):
                    r += img_1[k, l, 0]
                    g += img_1[k, l, 1]
                    b += img_1[k, l, 2]
                    pixeles += 1
            r //= pixeles
            g //= pixeles
            b //= pixeles
            r = np.uint8(r)
            g = np.uint8(g)
            b = np.uint8(b)
            orden.append((r, g, b))
            imagenes[(r, g, b)] = pintar_estrella(r, g, b, final_x, final_y)
    cant_regones_y = 0
    cant_regiones_x = 0
    for i in range(0, alto, tam_y):
        cant_regones_y += 1
    for j in range(0, ancho, tam_x):
        cant_regiones_x += 1
    return orden, cant_regones_y, cant_regiones_x, imagenes

# Funcion para dibujar una linea
def dibujar_linea(img, x1, y1, x2, y2, color):
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    sx = 1 if x1 < x2 else -1
    sy = 1 if y1 < y2 else -1
    err = dx - dy
    while True:
        if 0 <= y1 < img.shape[0] and 0 <= x1 < img.shape[1]:
            img[y1, x1] = color

        if x1 == x2 and y1 == y2:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x1 += sx
        if e2 < dx:
            err += dx
            y1 += sy

# Funcion para pintar una estrella
def pintar_estrella(r, g, b, tam_x, tam_y):
    img = np.ones((tam_y, tam_x, 3), np.uint8) * 255
    centro_x, centro_y = tam_x // 2, tam_y // 2
    radio_externo = min(tam_x, tam_y) // 2 - 1
    radio_interno = radio_externo // 2.5
    num_puntas = 5
    angulo_base = np.pi / num_puntas
    puntos = []
    for i in range(num_puntas * 2):
        radio = radio_externo if i % 2 == 0 else radio_interno
        angulo = i * angulo_base - np.pi / 2
        x = int(centro_x + radio * np.cos(angulo))
        y = int(centro_y + radio * np.sin(angulo))
        puntos.append((x, y))
    for i in range(len(puntos)):
        x1, y1 = puntos[i]
        x2, y2 = puntos[(i + 1) % len(puntos)]
        dibujar_linea(img, x1, y1, x2, y2, (r, g, b))
    cv2.fillPoly(img, [np.array(puntos, np.int32)], (int(r), int(g), int(b)))
    return img

# Funcion para aplicar mosaico a una imagen
def crear_mosaico(final_x, final_y, imagenes, orden, cant_regiones_y, cant_regiones_x):
    img_2 = np.ones((cant_regiones_y * final_y, cant_regiones_x * final_x, 3), np.uint8) * 255
    alto, ancho, canales = img_2.shape
    for i in range(0, alto, final_y):
        for j in range(0, ancho, final_x):
            numero = orden.pop(0)
            imagen = imagenes[(numero)]
            for k in range(final_y):
                for l in range(final_x):
                    img_2[i + k, j + l, 0] = imagen[k, l, 0]
                    img_2[i + k, j + l, 1] = imagen[k, l, 1]
                    img_2[i + k, j + l, 2] = imagen[k, l, 2]
            print(f"Quedan {len(orden)} regiones por procesar")
    return img_2


# Funcion para aplicar el filtro que ecualiza el histograma
def ecualizar(imagen):
    img = escala_grises(imagen).astype(np.uint8)
    alto, ancho, canales = img.shape
    img_2 = np.copy(img)
    total_pixeles = alto * ancho
    total_grises = 256
    hist = histograma_grises(img)
    hist_arr = np.zeros(total_grises, np.uint32)
    for nivel, cantidad in hist.items():
        hist_arr[nivel] = cantidad
    proba = hist_arr / total_pixeles
    cdf = np.cumsum(proba)
    transformacion = np.ceil(total_grises * cdf).astype(np.uint8) - 1
    transformacion = np.clip(transformacion, 0, 255)
    for i in range(alto):
        for j in range(ancho):
            gris = img[i, j, 0]
            nuevo_gris = transformacion[gris]
            img_2[i, j, 0] = nuevo_gris
            img_2[i, j, 1] = nuevo_gris
            img_2[i, j, 2] = nuevo_gris
    hist_2 = histograma_grises(img_2)
    return img_2, hist, hist_2

# Funcion para obtener el histograma de una imagen en escala de grises
def histograma_grises(imagen):
    alto, ancho, canales = imagen.shape
    valores = {}
    for i in range(alto):
        for j in range(ancho):
            gris = imagen[i, j, 0]
            if valores.get(gris) is None:
                valores[gris] = 1
            else:
                valores[gris] += 1
    return valores


# Diccionario de filtros basicos
filtros_basicos = {
    "Rojo": red,
    "Verde": green,
    "Azul": blue,
    "Escala de grises": escala_grises,
    "Escala de grises simple": escala_grises_simple,
    "Alto contraste": alto_contraste,
    "Inverso": inverso,
    "Brillo": brillo,
    "Componentes RGB": componentes_rgb,
    "Mosaico": mosaico
}

# Diccionario de filtros de imagen a HTML
filtros_html = {
    "Simbolo en colores": imagen_a_html,
    "Simbolo en escala de grises": imagen_a_html_gris,
    "Letras en escala de grises": imagen_a_html_letras,
    "Texto en colores": imagen_a_html_cadena,
    "Dominos": imagen_a_domino,
    "Dominos con fuente": imagen_a_domino_fuente,
    "Cartas": imagen_a_carta,
    "Cartas con fuente": imagen_a_carta_fuente
}

""" # Diccionario de filtros de quitar marca de agua
filtros_marca_agua = {
    "Quitar marca de agua imagen especifica": quitar_marca_agua
} """

# Diccionario de filtros de recursion
filtros_recursion = {
    "Colores reales": recursion_colores_reales
}

# Diccionario de filtros de dithering
filtros_dithering = {
    "Azar": dithering_azar,
    "Ordenado": dithering_ordenado,
    "Disperso 3x3": dithering_disperso,
    "Disperso 2x2": dithering_disperso_2x2,
    "Disperso 4x4": dithering_disperso_4x4,
    "Floyd-Steinberg": dithering_floyd_steinberg,
    "Floyd-Steinberg falso": dithering_floyd_steinberg_falso,
    "Jarvis, Judice y Ninke": dithering_jarvis_judice_ninke
}

# Diccionario de filtros de semitonos
filtros_semitono = {
    "Circulos": semitonos_circulos,
    "Matriz 3x3": semitonos_3x3,
    "Matriz 2x2": semitonos_2x2,
    "Dados grande": semitonos_dado_grande,
    "Dados": semitonos_dado
}

# Diccionario de filtros de posterizar y solarizar
filtros_posterizar_solarizar = {
    "Posterizar": posterizar,
    "Solarizar": solarizar
}

# Diccionario de filtros de oleo
filtros_oleo = {
    "Oleo": oleo,
    "Oleo blur": oleo_blur
}

# Diccionario de filtros de AT&T
filtros_at_t = {
    "AT&T": at_t,
    "AT&T gris": at_t_2
}

# Diccionario de filtros de mosaicos
filtros_mosaico = {
    "Mosaico circulos": mosaico_circulos,
    "Mosaico estrellas": mosaico_estrellas,
}

# Diccionario de filtros de ecualizacion de histograma
filtros_histograma = {
    "Ecualizar histograma": ecualizar
}


# Funciones para la interfaz grafica

# Funcion para aplicar un filtro sin parametros extras
def aplicar_filtro(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    img_array = filtros_basicos[tipo](ruta_imagen)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar el filtro brillo
def aplicar_brillo():
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valor_brillo = simpledialog.askinteger("Brillo", "Introduce un valor (-255 a 255):", minvalue=-255, maxvalue=255)
    if valor_brillo is None:
        return
    img_array = brillo(ruta_imagen, valor_brillo)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar el filtro componentes RGB
def aplicar_componentes_rgb():
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Componentes RGB", "Introduce los valores de R, G, B (0 a 255) separados por comas (ejemplo: 255,0,0):")
    if valores is None:
        return
    try:
        r, g, b = map(int, valores.split(","))
        if not (0 <= r <= 255 and 0 <= g <= 255 and 0 <= b <= 255):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa tres numeros entre 0 y 255 separados por comas")
        return
    img_array = componentes_rgb(ruta_imagen, r, g, b)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar el filtro mosaico
def aplicar_mosaico():
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Mosaico", "Introduce el tamanio de los bloques (x, y) separados por comas (ejemplo: 10,10):")
    if valores is None:
        return
    try:
        x, y = map(int, valores.split(","))
        if not (x > 0 and y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa dos numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if x > ancho or y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques no puede ser mayor al tamanio de la imagen")
        return
    img_array = mosaico(ruta_imagen, x, y)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de imagen a HTML
def aplicar_filtro_html(tipo):
    global ruta_imagen
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Imagen a HTML", "Introduce el tamano de letra, espacio entre lineas, tamanio de los bloques (x, y) separados por comas (ejemplo: 14,4,3,3):")
    if valores is None:
        return
    try:
        tam_letra, esp_entre_linea, tam_x, tam_y = map(int, valores.split(","))
        if not (tam_letra > 0 and esp_entre_linea > 0 and tam_x > 0 and tam_y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa cuatro numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if tam_x > ancho or tam_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques no puede ser mayor al tamanio de la imagen")
        return
    salida = filedialog.asksaveasfilename(filetypes=[("Archivos HTML", "*.html")])
    if not salida:
        return
    filtros_html[tipo](ruta_imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y)
    messagebox.showinfo("Listo", "La imagen ha sido guardada como HTML correctamente")

# Funcion para aplicar un filtro de imagen a HTML pidiento una cadena de caracteres
def aplicar_filtro_html_texto():
    global ruta_imagen
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Imagen a HTML", "Introduce el tamano de letra, espacio entre lineas, tamanio de los bloques (x, y) separados por comas (ejemplo: 14,4,3,3):")
    if valores is None:
        return
    try:
        tam_letra, esp_entre_linea, tam_x, tam_y = map(int, valores.split(","))
        if not (tam_letra > 0 and esp_entre_linea > 0 and tam_x > 0 and tam_y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa cuatro numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if tam_x > ancho or tam_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques no puede ser mayor al tamanio de la imagen")
        return
    texto = simpledialog.askstring("Imagen a HTML", "Introduce el texto a usar:")
    if texto is None:
        return
    salida = filedialog.asksaveasfilename(filetypes=[("Archivos HTML", "*.html")])
    if not salida:
        return
    imagen_a_html_cadena(ruta_imagen, salida, tam_letra, esp_entre_linea, tam_x, tam_y, texto)
    messagebox.showinfo("Listo", "La imagen ha sido guardada como HTML correctamente")

""" # Funcion para aplicar un filtro de quitado de marca de agua
def aplicar_filtro_marca_agua(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    img_array = filtros_marca_agua[tipo](ruta_imagen)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente") """

# Funcion para aplicar un filtro de recursion
def aplicar_filtro_recursion(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Recursion", "Introduce el tamanio de los bloques (x, y) de la imagen orignal y el tamanio de los bloques (x, y) de la imagen final separados por comas (ejemplo: 10,10,20,20):")
    if valores is None:
        return
    try:
        tam_x, tam_y, final_x, final_y = map(int, valores.split(","))
        if not (tam_x > 0 and tam_y > 0 and final_x > 0 and final_y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa cuatro numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if tam_x > ancho or tam_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen original no puede ser mayor al tamanio de la imagen")
        return
    if final_x > ancho or final_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen final no puede ser mayor al tamanio de la imagen")
        return
    imagen_micas = filedialog.askopenfilename(filetypes=[("Archivos de imagen", "*.png"), ("Archivos JPG", "*.jpg"), ("Archivos JPEG", "*.jpeg")])
    if not imagen_micas:
        return
    img_array = filtros_recursion[tipo](ruta_imagen, tam_x, tam_y, imagen_micas, final_x, final_y)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de dithering
def aplicar_filtro_dithering(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    img_array = filtros_dithering[tipo](ruta_imagen)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de semitonos
def aplicar_filtro_semitono(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Semitono", "Introduce el tamanio de los bloques (x, y) de la imagen orignal y el tamanio de los bloques (x, y) de la imagen final separados por comas (ejemplo: 5,5,15,15):")
    if valores is None:
        return
    try:
        tam_x, tam_y, final_x, final_y = map(int, valores.split(","))
        if not (tam_x > 0 and tam_y > 0 and final_x > 0 and final_y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa cuatro numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if tam_x > ancho or tam_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen original no puede ser mayor al tamanio de la imagen")
        return
    if final_x > ancho or final_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen final no puede ser mayor al tamanio de la imagen")
        return
    img_array = filtros_semitono[tipo](ruta_imagen, tam_x, tam_y, final_x, final_y)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de posterizar
def aplicar_filtro_posterizar(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valor = simpledialog.askinteger("Posterizar", "Introduce un valor de numero de niveles (2 a 256):", minvalue=2, maxvalue=256)
    if valor is None:
        return
    img_array = filtros_posterizar_solarizar[tipo](ruta_imagen, valor)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de solarizar
def aplicar_filtro_solarizar(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valor = simpledialog.askinteger("Solarizar", "Introduce un valor de umbral (0 a 255):", minvalue=0, maxvalue=255)
    if valor is None:
        return
    img_array = filtros_posterizar_solarizar[tipo](ruta_imagen, valor)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de oleo
def aplicar_filtro_oleo(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    img_array = filtros_oleo[tipo](ruta_imagen)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de oleo con blur
def aplicar_filtro_oleo_blur(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valor = simpledialog.askinteger("Oleo blur", "Introduce un valor de veces para aplicar blur (1 a 10):", minvalue=1, maxvalue=10)
    if valor is None:
        return
    img_array = filtros_oleo[tipo](ruta_imagen, valor)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de AT&T
def aplicar_filtro_at_t(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    valor = simpledialog.askinteger("AT&T", "Introduce un valor de pixeles entre las lineas:", minvalue=1, maxvalue=alto)
    if valor is None:
        return
    img_array = filtros_at_t[tipo](ruta_imagen, valor)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de mosaico
def aplicar_filtro_mosaico(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    valores = simpledialog.askstring("Mosaico", "Introduce el tamanio de los bloques (x, y) de la imagen orignal y el tamanio de los bloques (x, y) de la imagen final separados por comas (ejemplo: 5,5,15,15):")
    if valores is None:
        return
    try:
        tam_x, tam_y, final_x, final_y = map(int, valores.split(","))
        if not (tam_x > 0 and tam_y > 0 and final_x > 0 and final_y > 0):
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Ingresa cuatro numeros enteros positivos separados por comas")
        return
    alto, ancho, canales = imread(ruta_imagen).shape
    if tam_x > ancho or tam_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen original no puede ser mayor al tamanio de la imagen")
        return
    if final_x > ancho or final_y > alto:
        messagebox.showerror("Error", "El tamanio de los bloques de la imagen final no puede ser mayor al tamanio de la imagen")
        return
    img_array = filtros_mosaico[tipo](ruta_imagen, tam_x, tam_y, final_x, final_y)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")

# Funcion para aplicar un filtro de equilizacion de histograma
def aplicar_filtro_histograma(tipo):
    global ruta_imagen, panel_modificada, img_modificada
    if not ruta_imagen:
        messagebox.showerror("Error", "Primero selecciona una imagen")
        return
    img_array, hist, hist_2 = filtros_histograma[tipo](ruta_imagen)
    img_modificada = Image.fromarray(img_array.astype(np.uint8))
    img_tk = ImageTk.PhotoImage(img_modificada)
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk
    messagebox.showinfo("Listo", "La imagen ha sido modificada correctamente")
    plt.figure(figsize=(10, 5))
    plt.subplot(1, 2, 1)
    plt.title("Histograma Original")
    plt.bar(hist.keys(), hist.values(), color='gray')
    plt.subplot(1, 2, 2)
    plt.title("Histograma Ecualizado")
    plt.bar(hist_2.keys(), hist_2.values(), color='gray')
    plt.show()


# Funcion para seleccionar una imagen
def seleccionar_imagen():
    global ruta_imagen, panel_original, panel_modificada
    ruta_imagen = filedialog.askopenfilename(filetypes=[("Archivos de imagen", "*.png"), ("Archivos JPG", "*.jpg"), ("Archivos JPEG", "*.jpeg")] )
    if not ruta_imagen:
        return
    img_original = Image.open(ruta_imagen).convert("RGB")
    img_tk = ImageTk.PhotoImage(img_original)
    panel_original.config(image=img_tk)
    panel_original.image = img_tk
    panel_modificada.config(image=img_tk)
    panel_modificada.image = img_tk

# Funcion para guardar la imagen modificada
def guardar_imagen():
    global img_modificada
    if img_modificada is None:
        messagebox.showerror("Error", "No hay imagen modificada para guardar")
        return
    ruta_salida = filedialog.asksaveasfilename(filetypes=[("Archivos de imagen", "*.png"), ("Archivos JPG", "*.jpg"), ("Archivos JPEG", "*.jpeg")])
    if ruta_salida:
        img_modificada.save(ruta_salida)
        messagebox.showinfo("Listo", "La imagen ha sido guardada correctamente")

# Interfaz grafica

root = tk.Tk()
root.title("Filtros de Imagenes")
root.geometry("1500x800")

# Menu
menubar = Menu(root)
root.config(menu=menubar)

# Menu Archivo
menu_archivo = Menu(menubar, tearoff=0)
menu_archivo.add_command(label="Abrir Imagen", command=seleccionar_imagen)
menu_archivo.add_command(label="Guardar Imagen", command=guardar_imagen)
menubar.add_cascade(label="Archivo", menu=menu_archivo)

# Menu Filtros Basicos
menu_filtros = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_basicos.items():
    if filtro.__code__.co_argcount == 1:
        menu_filtros.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro(nombre))
    elif nombre == "Brillo":
        menu_filtros.add_command(label=nombre, command=aplicar_brillo)
    elif nombre == "Componentes RGB":
        menu_filtros.add_command(label=nombre, command=aplicar_componentes_rgb)
    elif nombre == "Mosaico":
        menu_filtros.add_command(label=nombre, command=aplicar_mosaico)
menubar.add_cascade(label="Filtros Basicos", menu=menu_filtros)

# Menu Filtros HTML
menu_filtros_html = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_html.items():
    if filtro.__code__.co_argcount == 6:
        menu_filtros_html.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_html(nombre))
    elif nombre == "Texto en colores":
        menu_filtros_html.add_command(label=nombre, command=aplicar_filtro_html_texto)
menubar.add_cascade(label="Filtros HTML", menu=menu_filtros_html)

""" # Menu Filtros Quitar marca de agua
menu_filtros_marca_agua = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_marca_agua.items():
    menu_filtros_marca_agua.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_marca_agua(nombre))
menubar.add_cascade(label="Filtros Marca de Agua", menu=menu_filtros_marca_agua) """

# Menu Filtros Recursion
menu_filtros_recursion = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_recursion.items():
    menu_filtros_recursion.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_recursion(nombre))
menubar.add_cascade(label="Filtros Recursion", menu=menu_filtros_recursion)

# Menu Filtros Dithering
menu_filtros_dithering = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_dithering.items():
    menu_filtros_dithering.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_dithering(nombre))
menubar.add_cascade(label="Filtros Dithering", menu=menu_filtros_dithering)

# Menu Filtros Semitonos
menu_filtros_semitono = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_semitono.items():
    menu_filtros_semitono.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_semitono(nombre))
menubar.add_cascade(label="Filtros Semitonos", menu=menu_filtros_semitono)

# Menu Filtros Posterizar y Solarizar
menu_filtros_posterizar_solarizar = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_posterizar_solarizar.items():
    if nombre == "Posterizar":
        menu_filtros_posterizar_solarizar.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_posterizar(nombre))
    elif nombre == "Solarizar":
        menu_filtros_posterizar_solarizar.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_solarizar(nombre))
menubar.add_cascade(label="Filtros Posterizar y Solarizar", menu=menu_filtros_posterizar_solarizar)

# Menu Filtros Oleo
menu_filtros_oleo = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_oleo.items():
    if nombre == "Oleo":
        menu_filtros_oleo.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_oleo(nombre))
    elif nombre == "Oleo blur":
        menu_filtros_oleo.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_oleo_blur(nombre))
menubar.add_cascade(label="Filtros Oleo", menu=menu_filtros_oleo)

# Menu Filtros AT&T
menu_filtros_at_t = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_at_t.items():
    menu_filtros_at_t.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_at_t(nombre))
menubar.add_cascade(label="Filtros AT&T", menu=menu_filtros_at_t)

# Menu Filtros Mosaico
menu_filtros_mosaico = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_mosaico.items():
    menu_filtros_mosaico.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_mosaico(nombre))
menubar.add_cascade(label="Filtros Mosaico", menu=menu_filtros_mosaico)

# Menu Filtros Ecualizacion de histograma
menu_filtros_histograma = Menu(menubar, tearoff=0)
for nombre, filtro in filtros_histograma.items():
    menu_filtros_histograma.add_command(label=nombre, command=lambda nombre=nombre: aplicar_filtro_histograma(nombre))
menubar.add_cascade(label="Filtros Ecualizacion", menu=menu_filtros_histograma)

# Seccion de imagenes
frame_imagenes = tk.Frame(root)
frame_imagenes.pack(pady=10)

panel_original = tk.Label(frame_imagenes)
panel_original.pack(side="left", padx=10)

panel_modificada = tk.Label(frame_imagenes)
panel_modificada.pack(side="left", padx=10)

ruta_imagen = None
img_modificada = None

root.mainloop()
